package com.example.newgmailforexample.models;

public class SocialModel {
    String name;

    public SocialModel(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;


    }
}

package com.example.newgmailforexample.models;

public class StarredModel {
    String name;

    public StarredModel(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;


    }
}

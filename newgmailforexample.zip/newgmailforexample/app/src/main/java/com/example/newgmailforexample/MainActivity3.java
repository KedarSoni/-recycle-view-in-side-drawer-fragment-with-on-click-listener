package com.example.newgmailforexample;


import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.newgmailforexample.models.AllinboxModel;
import com.example.newgmailforexample.models.SnoozedModel;


public class MainActivity3 extends AppCompatActivity {

    SnoozedModel album;

    ImageView err;
    TextView t1,t2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        album = (SnoozedModel) getIntent().getSerializableExtra("album");


/*        int c = 10;
          double a = 12.34;
           int d = (int) a;
           Log.e("d",d+"");*/

        Log.e("name",album.getCourse_name());

        err=(ImageView) findViewById(R.id.idIVCourseImage2);
        err.setImageResource(album.getCourse_image());


        t1=(TextView) findViewById(R.id.idTVCourseName2);
        t1.setText(album.getCourse_name());

        t2=(TextView) findViewById(R.id.idTVCourseRating2);
        t2.setText(album.getCourse_rating() +"");

    }

}


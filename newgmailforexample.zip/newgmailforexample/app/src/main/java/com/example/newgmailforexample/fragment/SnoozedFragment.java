package com.example.newgmailforexample.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.newgmailforexample.adapter.Allinboxadapter;
import com.example.newgmailforexample.MainActivity2;
import com.example.newgmailforexample.adapter.SnoozedAdapter;
import com.example.newgmailforexample.models.AllinboxModel;
import com.example.newgmailforexample.R;
import com.example.newgmailforexample.models.SnoozedModel;

import java.util.ArrayList;


public class SnoozedFragment extends Fragment {
    private RecyclerView courseRV;

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    public SnoozedFragment() {

    }


    public static SnoozedFragment newInstance(String param1, String param2) {
        SnoozedFragment fragment = new SnoozedFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_snoozed, container, false);

        courseRV = v.findViewById(R.id.idRVCourse);

        // here we have created new array list and added data to it.
        ArrayList<SnoozedModel> courseModelArrayList= new ArrayList<>();
        courseModelArrayList.add(new SnoozedModel("55555", 4, R.drawable.img));
        courseModelArrayList.add(new SnoozedModel("khvhjvj" +
                "", 3, R.drawable.img));
        courseModelArrayList.add(new SnoozedModel("C++ COurse", 4, R.drawable.img));
        courseModelArrayList.add(new SnoozedModel("DSA in C++", 4, R.drawable.img));
        courseModelArrayList.add(new SnoozedModel("Kotlin for Android", 4, R.drawable.img));
        courseModelArrayList.add(new SnoozedModel("Java for Android", 4, R.drawable.img));
        courseModelArrayList.add(new SnoozedModel("HTML and CSS", 4, R.drawable.img));

        // we are initializing our adapter class and passing our arraylist to it.
        SnoozedAdapter courseAdapter = new SnoozedAdapter(getContext(), courseModelArrayList);

        // below line is for setting a layout manager for our recycler view.
        // here we are creating vertical list so we will provide orientation as vertical
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false);

        // in below two lines we are setting layoutmanager and adapter to our recycler view.
        courseRV.setLayoutManager(linearLayoutManager);
        courseRV.setAdapter(courseAdapter);


        return v;
    }
}
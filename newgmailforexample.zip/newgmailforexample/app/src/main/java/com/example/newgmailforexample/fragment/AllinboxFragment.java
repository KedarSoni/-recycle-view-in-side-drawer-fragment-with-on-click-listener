package com.example.newgmailforexample.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.newgmailforexample.adapter.Allinboxadapter;
import com.example.newgmailforexample.MainActivity2;
import com.example.newgmailforexample.models.AllinboxModel;
import com.example.newgmailforexample.R;

import java.util.ArrayList;


public class AllinboxFragment extends Fragment {
    private RecyclerView courseRV;

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    public AllinboxFragment() {

    }


    public static AllinboxFragment newInstance(String param1, String param2) {
        AllinboxFragment fragment = new AllinboxFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_allinbox, container, false);

        courseRV = v.findViewById(R.id.idRVCourse);

        // here we have created new array list and added data to it.
        ArrayList<AllinboxModel> courseModelArrayList= new ArrayList<>();
        courseModelArrayList.add(new AllinboxModel("DSA in Java", 4, R.drawable.img));
        courseModelArrayList.add(new AllinboxModel("Java Course", 3, R.drawable.img));
        courseModelArrayList.add(new AllinboxModel("C++ COurse", 4, R.drawable.img));
        courseModelArrayList.add(new AllinboxModel("DSA in C++", 4, R.drawable.img));
        courseModelArrayList.add(new AllinboxModel("Kotlin for Android", 4, R.drawable.img));
        courseModelArrayList.add(new AllinboxModel("Java for Android", 4, R.drawable.img));
        courseModelArrayList.add(new AllinboxModel("HTML and CSS", 4, R.drawable.img));

        // we are initializing our adapter class and passing our arraylist to it.
        Allinboxadapter courseAdapter = new Allinboxadapter(getContext(), courseModelArrayList);

        // below line is for setting a layout manager for our recycler view.
        // here we are creating vertical list so we will provide orientation as vertical
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false);

        // in below two lines we are setting layoutmanager and adapter to our recycler view.
        courseRV.setLayoutManager(linearLayoutManager);
        courseRV.setAdapter(courseAdapter);


        return v;
    }
}
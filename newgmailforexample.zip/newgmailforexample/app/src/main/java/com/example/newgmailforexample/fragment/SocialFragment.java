package com.example.newgmailforexample.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.newgmailforexample.R;
import com.example.newgmailforexample.adapter.SocialAdapter;
import com.example.newgmailforexample.models.SocialModel;

import java.util.ArrayList;
import java.util.List;

public class SocialFragment extends Fragment {

    RecyclerView recyclerView;
    List<com.example.newgmailforexample.models.SocialModel> SocialModel = new ArrayList<>();



    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public SocialFragment() {
        // Required empty public constructor
    }

    public static SocialFragment newInstance(String param1, String param2) {
        SocialFragment fragment = new SocialFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_social, container, false);

        recyclerView = v.findViewById(R.id.recyclerViewsocial);

        SocialModel.add(new SocialModel("1"));
      SocialModel.add(new SocialModel("2"));
      SocialModel.add(new SocialModel("2 c2"));
      SocialModel.add(new SocialModel("22 2"));
      SocialModel.add(new SocialModel("66666666666666 3"));
      SocialModel.add(new SocialModel("s 4"));
      SocialModel.add(new SocialModel("dd s"));
      SocialModel.add(new SocialModel("ddd s"));
      SocialModel.add(new SocialModel("s 6"));
      SocialModel.add(new SocialModel("s 77"));

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(new SocialAdapter(SocialModel));

        return v;
    }
}
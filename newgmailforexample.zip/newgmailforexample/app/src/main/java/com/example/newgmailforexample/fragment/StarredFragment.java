package com.example.newgmailforexample.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.newgmailforexample.R;
import com.example.newgmailforexample.adapter.StarredAdapter;
import com.example.newgmailforexample.models.StarredModel;

import java.util.ArrayList;
import java.util.List;


public class StarredFragment extends Fragment {
    RecyclerView recyclerView;
    List<StarredModel> StarredModel = new ArrayList<>();

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";


    private String mParam1;
    private String mParam2;

    public StarredFragment() {
        // Required empty public constructor
    }


    public static StarredFragment newInstance(String param1, String param2) {
        StarredFragment fragment = new StarredFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_starred, container, false);

        recyclerView = v.findViewById(R.id.recyclerViewstarred);

        StarredModel.add(new StarredModel("s1"));
        StarredModel.add(new StarredModel("sss"));
        StarredModel.add(new StarredModel("ss c2"));
        StarredModel.add(new StarredModel("ss 2"));
        StarredModel.add(new StarredModel("s 3"));
        StarredModel.add(new StarredModel("s 4"));
        StarredModel.add(new StarredModel("ss 5"));
        StarredModel.add(new StarredModel("s 5"));
        StarredModel.add(new StarredModel("sss 6"));
        StarredModel.add(new StarredModel("dvdfgszfdgdfgdzfggadghdffbdfb 77"));

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(new StarredAdapter(StarredModel));

        return v;
    }
}